package com.mycompany.demoproject;

import javax.swing.JOptionPane;

public class NewWindow extends javax.swing.JFrame {

    private String nombre;
    private int edad = -1;
    private String profecion;
    private String ciudad;
    private String pais;
    
    public NewWindow() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8Nombre = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14Edad = new javax.swing.JLabel();
        jLabel15Profecion = new javax.swing.JLabel();
        jLabel16Ciudad = new javax.swing.JLabel();
        jLabel17País = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextFieldName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField2Edad = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3Profeción = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4Ciudad = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField5Paiz = new javax.swing.JTextField();
        jButton1Registrar = new javax.swing.JButton();
        jButton2Mostrar = new javax.swing.JButton();
        jButton3Exit = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel7.setText("Nombre:");

        jLabel8Nombre.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel9.setText("Datos generales:");

        jLabel10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel10.setText("Edad:");

        jLabel11.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel11.setText("Profeción:");

        jLabel12.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel12.setText("Ciudad:");

        jLabel8.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel8.setText("País:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 567, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel15Profecion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel17País, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(jLabel14Edad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel16Ciudad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(10, 10, 10))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                    .addComponent(jLabel8Nombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(1, 1, 1)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14Edad, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15Profecion, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16Ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel17País, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Usuario", jPanel1);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 720, 290));

        jTextFieldName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNameActionPerformed(evt);
            }
        });
        getContentPane().add(jTextFieldName, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 190, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 20));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("Edad:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 80, 20));
        getContentPane().add(jTextField2Edad, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 190, -1));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("Profeción:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 80, 20));

        jTextField3Profeción.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ProfeciónActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3Profeción, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 190, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("Ciudad:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 80, 20));
        getContentPane().add(jTextField4Ciudad, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 190, -1));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel6.setText("País:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 80, 20));
        getContentPane().add(jTextField5Paiz, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 190, -1));

        jButton1Registrar.setBackground(new java.awt.Color(0, 204, 204));
        jButton1Registrar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton1Registrar.setText("Registrar");
        jButton1Registrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1RegistrarMouseClicked(evt);
            }
        });
        jButton1Registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1RegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 130, 170, -1));

        jButton2Mostrar.setBackground(new java.awt.Color(0, 204, 204));
        jButton2Mostrar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton2Mostrar.setText("Mostrar");
        jButton2Mostrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MostrarMouseClicked(evt);
            }
        });
        jButton2Mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2MostrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2Mostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 130, 170, -1));

        jButton3Exit.setBackground(new java.awt.Color(255, 102, 102));
        jButton3Exit.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton3Exit.setText("Salir");
        jButton3Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3ExitMouseClicked(evt);
            }
        });
        getContentPane().add(jButton3Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 80, -1));

        jLabel13.setForeground(new java.awt.Color(255, 0, 51));
        jLabel13.setText("El programa captura la información escrita en los JTextField, la registra en");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 390, 20));

        jLabel14.setForeground(new java.awt.Color(255, 0, 51));
        jLabel14.setText("el JButton \"Registrar\" y la muestra e el JButton \"Mostrar\". para salir precionar");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, 390, 20));

        jLabel15.setForeground(new java.awt.Color(255, 0, 51));
        jLabel15.setText("el JButton \"Salir\" donde saldra una JDialog que preguntara si quieres salir o no");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 400, 20));

        jLabel1.setBackground(new java.awt.Color(153, 255, 204));
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 718, 180));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNameActionPerformed
        
    }//GEN-LAST:event_jTextFieldNameActionPerformed

    private void jTextField3ProfeciónActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ProfeciónActionPerformed

    }//GEN-LAST:event_jTextField3ProfeciónActionPerformed

    private void jButton1RegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1RegistrarActionPerformed
        
    }//GEN-LAST:event_jButton1RegistrarActionPerformed

    private void jButton2MostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2MostrarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2MostrarActionPerformed

    private void jButton1RegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1RegistrarMouseClicked
        try{
            nombre = this.jTextFieldName.getText();
            edad = Integer.parseInt(this.jTextField2Edad.getText());
            profecion = this.jTextField3Profeción.getText();
            ciudad = this.jTextField4Ciudad.getText();
            pais = this.jTextField5Paiz.getText();
            
            if(nombre == null || "".equals(nombre)){
                JOptionPane.showMessageDialog(this,"Capturé todos los campos");
                return;
            }else if((edad == -1)){
                JOptionPane.showMessageDialog(this,"Capturé todos los campos");
                return;
            }else if(profecion == null || "".equals(profecion)){
                JOptionPane.showMessageDialog(this,"Capturé todos los campos");
                return;
            }else if(ciudad == null || "".equals(ciudad)){
                JOptionPane.showMessageDialog(this,"Capturé todos los campos");
                return;
            }else if(pais == null || "".equals(pais)){
                JOptionPane.showMessageDialog(this,"Capturé todos los campos");
                return;
            }          
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"No capturó uno de los campos de texto correctamente");
            return;
        }
        JOptionPane.showMessageDialog(this, "Datos capturados");
    }//GEN-LAST:event_jButton1RegistrarMouseClicked

    private void jButton2MostrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MostrarMouseClicked
        if(nombre == null || "".equals(nombre)){
            JOptionPane.showMessageDialog(this,"Los campos de texto deven ser llenados en su totalidad para poder mostrar la información");
            return;
        }else if((edad == -1)){
            JOptionPane.showMessageDialog(this,"Los campos de texto deven ser llenados en su totalidad para poder mostrar la información");
            return;
        }else if(profecion == null || "".equals(profecion)){
            JOptionPane.showMessageDialog(this,"Los campos de texto deven ser llenados en su totalidad para poder mostrar la información");
            return;
        }else if(ciudad == null || "".equals(ciudad)){
            JOptionPane.showMessageDialog(this,"Los campos de texto deven ser llenados en su totalidad para poder mostrar la información");
            return;
        }else if(pais == null || "".equals(pais)){
            JOptionPane.showMessageDialog(this,"Los campos de texto deven ser llenados en su totalidad para poder mostrar la información");
            return;
        }
       
        this.jLabel8Nombre.setText(this.nombre);
        this.jLabel15Profecion.setText(this.profecion);
        this.jLabel16Ciudad.setText(this.ciudad);
        this.jLabel17País.setText(pais);
        this.jLabel14Edad.setText(this.edad + "");
    }//GEN-LAST:event_jButton2MostrarMouseClicked

    private void jButton3ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3ExitMouseClicked
        NewJDialog salir = new NewJDialog(this,true);
        salir.setVisible(true);
    }//GEN-LAST:event_jButton3ExitMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1Registrar;
    private javax.swing.JButton jButton2Mostrar;
    private javax.swing.JButton jButton3Exit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel14Edad;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel15Profecion;
    private javax.swing.JLabel jLabel16Ciudad;
    private javax.swing.JLabel jLabel17País;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel8Nombre;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField2Edad;
    private javax.swing.JTextField jTextField3Profeción;
    private javax.swing.JTextField jTextField4Ciudad;
    private javax.swing.JTextField jTextField5Paiz;
    private javax.swing.JTextField jTextFieldName;
    // End of variables declaration//GEN-END:variables
}
